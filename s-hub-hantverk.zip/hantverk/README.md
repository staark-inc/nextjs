# S-Hub Hantverk

Child theme of S-Hub Light for trades: bygg, VVS, renovering, tak, måleri.
It inherits every Light section through `parentId: "light"`, overrides `hero`
and `process` (same props as Light), and adds the trades blocks below.

## Blocks

| `type` | What it does |
| --- | --- |
| `emergencyBanner` | "Jour" strip under the header, plus a sticky Ring / Begär offert bar on phones. Put it first on the page. |
| `hero` | Light hero props plus `showPhone` (call button from the site phone) and an optional `quickQuote` card whose chips link to the quote form with the job preselected (`?jobb=`). |
| `trustBar` | Credentials and promises: F-skatt, behörighet, fast pris, garanti. |
| `rotCalculator` | Interactive estimate after ROT-avdrag. `rate` (default 30) and `capPerPerson` (default 50 000) are props, so a rule change is a content edit, not a redeploy. |
| `process` | Numbered steps with heavy rules. |
| `beforeAfter` | One project with a before/after slider and key facts. |
| `quoteRequest` | Three-step offert form (jobb → detaljer → kontakt) posting to `/api/staark/forms` → S-Hub Inbox. Only whitelisted fields are sent: job, postnummer and start are composed into `subject` + `message`. Service areas and opening hours sit beside it. |

## Preset

`presets/hantverk.json` — limestone paper, graphite ink, burnt-orange accent,
condensed uppercase Archivo headings, 4 px corners. It uses three optional
typography tokens, applied by the theme's own (scoped) stylesheet:
`headingWeight`, `headingStretch`, `headingCase`, plus `label` for eyebrows and
small captions.

Fonts are self-hosted through Fontsource (no Google Fonts request).

## Install

See [INSTALL.md](INSTALL.md): five small registrations in `apps/starter`, plus
optional `/admin` wiring through `@staark/theme-hantverk/admin`. A demo site
("Nordvik Bygg") ships in `demo/`.
