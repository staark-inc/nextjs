# Instalare S-Hub Hantverk

Pachetul conține tot ce ține de temă: secțiunile, preset-ul, stilurile, fonturile,
definițiile pentru `/admin` și un site demo („Nordvik Bygg”). Aplicația `apps/starter`
trebuie doar să afle că tema există: 5 pași obligatorii și 3 opționali.

Toate comenzile sunt date pentru PowerShell, rulate din rădăcina repo-ului `nextjs`.

## 1. Copiază folderul

Dezarhivează ca să ajungă la `themes/hantverk` (lângă `themes/light`, `themes/salong` …).

## 2. Dependința în starter

În `apps/starter/package.json`, la `dependencies`:

```json
"@staark/theme-hantverk": "workspace:*",
```

## 3. `apps/starter/next.config.ts`

Adaugă tema în `transpilePackages`:

```ts
transpilePackages: [/* … */, "@staark/theme-webb", "@staark/theme-hantverk"],
```

## 4. `apps/starter/lib/theme-runtime.ts`

```ts
import hantverkTheme, { hantverkRegistry } from "@staark/theme-hantverk";

// în obiectul THEMES:
  hantverk: {
    id: "hantverk",
    name: hantverkTheme.name,
    description: "Trades theme (bygg, VVS, renovering) with ROT calculator, before/after and stepwise quote requests.",
    theme: hantverkTheme,
    registry: hantverkRegistry,
  },
```

## 5. `apps/starter/app/(site)/layout.tsx`

După celelalte importuri de stiluri:

```ts
import "@staark/theme-hantverk/styles.css";
```

Stilurile sunt izolate (`.sk-hv-*` și variantele alese doar de preset-ul Hantverk),
deci nu afectează celelalte teme.

## Instalează și pornește demo-ul

```powershell
pnpm install
Copy-Item -Recurse themes\hantverk\demo\content apps\starter\content\hantverk
Copy-Item -Recurse themes\hantverk\demo\public\hantverk apps\starter\public\hantverk
```

În `apps\starter\.env.local`:

```
STAARK_CONTENT_SOURCE=fixtures
STAARK_THEME=hantverk
STAARK_CONTENT_DIR=content/hantverk
```

```powershell
pnpm dev
```

Deschide http://localhost:3200.

## Opțional: integrarea în `/admin`

Fără acești pași site-ul merge normal. Blocks-urile noi se editează atunci ca JSON,
iar pickerul nu le arată.

**a) Formulare pentru blocks** — `apps/starter/lib/block-fields.ts`:

```ts
import { hantverkBlockFields, hantverkHeroFields, hantverkRequiredFields } from "@staark/theme-hantverk/admin";

// în BLOCK_FIELDS.hero, după "points":
    ...(hantverkHeroFields as Field[]),
// la sfârșitul BLOCK_FIELDS:
  ...(hantverkBlockFields as Record<string, Field[]>),
// la sfârșitul REQUIRED_FIELDS:
  ...hantverkRequiredFields,
```

**b) Blocks în picker** — `apps/starter/app/api/admin/blocks/route.ts`:

```ts
import { hantverkBlockTemplates } from "@staark/theme-hantverk/admin";

const THEME_BLOCKS: Record<string, BlockTemplate[]> = {
  hantverk: hantverkBlockTemplates,
  // salong, gastfrihet …
};
```

**c) Template-uri de pagină** — `apps/starter/app/api/admin/pages/route.ts`:

```ts
import { hantverkPageTemplates } from "@staark/theme-hantverk/admin";

// în templatesFor(theme):
  if (theme === "hantverk") {
    base.push(...hantverkPageTemplates.map(({ id, label, description }) => ({ id, label, description, theme })));
  }

// în blocksFor(templateId, title), ramura default:
    default:
      return hantverkPageTemplates.find((t) => t.id === templateId)?.blocks(title) ?? [];
```

Tema apare și în Theme Studio dacă adaugi `"hantverk"` în `BUILT_IN_THEME_IDS`
din `apps/starter/lib/theme-studio.ts`.

## Verificare

```powershell
pnpm typecheck
pnpm test
pnpm build
```
