import type { ThemeDefinition } from "@staark/theme-kit";
import lightTheme from "@staark/theme-light";
import hantverk from "../presets/hantverk.json" with { type: "json" };
import { Hero } from "./sections/Hero";
import { Process } from "./sections/Process";
import { TrustBar } from "./sections/TrustBar";
import { RotCalculator } from "./sections/RotCalculator";
import { BeforeAfter } from "./sections/BeforeAfter";
import { QuoteRequest } from "./sections/QuoteRequest";
import { EmergencyBanner } from "./sections/EmergencyBanner";

/**
 * S-Hub Hantverk — child theme for trades (bygg, VVS, renovering). It inherits
 * every S-Hub Light section through `parentId: "light"`, overrides `hero` and
 * `process` with the same props, and adds the trades sections: trust bar,
 * ROT calculator, before/after, stepwise quote request and the jour banner.
 */
export const hantverkTheme: ThemeDefinition = {
  id: "hantverk",
  name: "S-Hub Hantverk",
  parentId: "light",
  presets: {
    hantverk: hantverk as ThemeDefinition["presets"][string],
  },
  defaultPreset: "hantverk",
  sections: {
    hero: Hero,
    process: Process,
    trustBar: TrustBar,
    rotCalculator: RotCalculator,
    beforeAfter: BeforeAfter,
    quoteRequest: QuoteRequest,
    emergencyBanner: EmergencyBanner,
  },
};

/** Registry to pass to BlockRenderer so parent sections resolve. */
export const hantverkRegistry: Record<string, ThemeDefinition> = {
  light: lightTheme,
  hantverk: hantverkTheme,
};

export { Hero, Process, TrustBar, RotCalculator, BeforeAfter, QuoteRequest, EmergencyBanner };
export { computeRot, formatKr } from "./rot";
export default hantverkTheme;
