"use client";

import { useId, useState } from "react";

export type CompareProps = {
  before: { src: string; alt: string };
  after: { src: string; alt: string };
  beforeLabel: string;
  afterLabel: string;
  hint: string;
};

/** Before/after image comparison driven by a native range input (keyboard + touch friendly). */
export function CompareSlider({ before, after, beforeLabel, afterLabel, hint }: CompareProps) {
  const id = useId();
  const [split, setSplit] = useState(50);

  return (
    <div className="sk-hv-compare">
      <div className="sk-hv-compare__stage">
        <img className="sk-hv-cover" src={after.src} alt={after.alt} loading="lazy" decoding="async" />
        <div className="sk-hv-compare__before" style={{ clipPath: `inset(0 ${100 - split}% 0 0)` }}>
          <img className="sk-hv-cover" src={before.src} alt={before.alt} loading="lazy" decoding="async" />
        </div>
        <span className="sk-hv-compare__divider" style={{ left: `${split}%` }} aria-hidden />
        <span className="sk-hv-compare__tag sk-hv-compare__tag--before">{beforeLabel}</span>
        <span className="sk-hv-compare__tag sk-hv-compare__tag--after">{afterLabel}</span>
      </div>
      <label className="sk-hv-compare__hint" htmlFor={id}>
        {hint}
      </label>
      <input id={id} type="range" min={0} max={100} value={split} onChange={(e) => setSplit(Number(e.target.value))} />
    </div>
  );
}
