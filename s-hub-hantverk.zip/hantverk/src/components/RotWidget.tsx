"use client";

import { useId, useState } from "react";
import { computeRot, formatKr } from "../rot";

export type RotWidgetProps = {
  ratePercent: number;
  capPerPerson: number;
  maxAmount: number;
  step: number;
  defaultLabor: number;
  defaultMaterial: number;
  defaultPersons: 1 | 2;
  labels: {
    labor: string;
    material: string;
    persons: string;
    total: string;
    deduction: string;
    pay: string;
    capped: string;
  };
};

export function RotWidget(props: RotWidgetProps) {
  const id = useId();
  const [labor, setLabor] = useState(props.defaultLabor);
  const [material, setMaterial] = useState(props.defaultMaterial);
  const [persons, setPersons] = useState<1 | 2>(props.defaultPersons);
  const r = computeRot({ labor, material, persons, ratePercent: props.ratePercent, capPerPerson: props.capPerPerson });

  return (
    <div className="sk-hv-rot__card">
      <div className="sk-hv-rot__field">
        <div className="sk-hv-rot__row">
          <label htmlFor={`${id}-labor`}>{props.labels.labor}</label>
          <output htmlFor={`${id}-labor`}>{formatKr(labor)}</output>
        </div>
        <input id={`${id}-labor`} type="range" min={0} max={props.maxAmount} step={props.step} value={labor} onChange={(e) => setLabor(Number(e.target.value))} />
      </div>

      <div className="sk-hv-rot__field">
        <div className="sk-hv-rot__row">
          <label htmlFor={`${id}-material`}>{props.labels.material}</label>
          <output htmlFor={`${id}-material`}>{formatKr(material)}</output>
        </div>
        <input id={`${id}-material`} type="range" min={0} max={props.maxAmount} step={props.step} value={material} onChange={(e) => setMaterial(Number(e.target.value))} />
      </div>

      <fieldset className="sk-hv-rot__persons">
        <legend>{props.labels.persons}</legend>
        <div className="sk-hv-segment">
          {([1, 2] as const).map((n) => (
            <button key={n} type="button" aria-pressed={persons === n} onClick={() => setPersons(n)}>
              {n}
            </button>
          ))}
        </div>
      </fieldset>

      <dl className="sk-hv-rot__sum">
        <div>
          <dt>{props.labels.total}</dt>
          <dd>{formatKr(r.total)}</dd>
        </div>
        <div className="sk-hv-rot__deduction">
          <dt>{props.labels.deduction}</dt>
          <dd>− {formatKr(r.deduction)}</dd>
        </div>
      </dl>
      {r.capped ? <p className="sk-hv-rot__capped">{props.labels.capped}</p> : null}

      <div className="sk-hv-rot__pay" aria-live="polite">
        <span>{props.labels.pay}</span>
        <strong>{formatKr(r.pay)}</strong>
      </div>
    </div>
  );
}
