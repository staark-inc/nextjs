/**
 * ROT-avdrag arithmetic, kept pure so it can be unit-tested and shared by the
 * calculator block. The rate and the per-person yearly cap are block props, set
 * from /admin or the Hub, because the rules change (30 % / 50 000 kr in 2026).
 */

export type RotInput = {
  /** Labour cost incl. VAT, in kronor. Only labour qualifies for ROT. */
  labor: number;
  /** Material, travel and other costs, in kronor. Never deductible. */
  material: number;
  /** Number of people sharing the deduction (each has their own cap). */
  persons: number;
  /** Deduction rate in percent, e.g. 30. */
  ratePercent: number;
  /** Max deduction per person and year, in kronor. */
  capPerPerson: number;
};

export type RotResult = {
  total: number;
  deduction: number;
  pay: number;
  /** True when the cap, not the rate, limited the deduction. */
  capped: boolean;
};

function clean(value: number): number {
  return Number.isFinite(value) && value > 0 ? value : 0;
}

export function computeRot(input: RotInput): RotResult {
  const labor = clean(input.labor);
  const material = clean(input.material);
  const persons = Math.max(1, Math.floor(clean(input.persons)) || 1);
  const rate = Math.min(clean(input.ratePercent), 100) / 100;
  const cap = clean(input.capPerPerson) * persons;

  const uncapped = Math.round(labor * rate);
  const deduction = Math.min(uncapped, cap);
  const total = labor + material;
  return { total, deduction, pay: total - deduction, capped: uncapped > cap };
}

const SEK = new Intl.NumberFormat("sv-SE", { maximumFractionDigits: 0 });

export function formatKr(value: number): string {
  return `${SEK.format(Math.round(value))} kr`;
}
