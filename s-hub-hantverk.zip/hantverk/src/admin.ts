/**
 * Admin integration for S-Hub Hantverk: field descriptors for the /admin block
 * editor, required fields, block-picker templates and page templates. Plain
 * data, so the starter app can spread it into its own registries without the
 * theme depending on the app. See INSTALL.md.
 */

export type AdminField = {
  name: string;
  label: string;
  type: "text" | "textarea" | "number" | "boolean" | "select" | "image" | "imageUrl" | "icon" | "link" | "array" | "object";
  help?: string;
  placeholder?: string;
  options?: (string | number | { label: string; value: string | number })[];
  min?: number;
  max?: number;
  itemLabel?: string;
  fields?: AdminField[];
};

export type AdminBlockTemplate = {
  type: string;
  label: string;
  description: string;
  icon: string;
  template: Record<string, unknown>;
};

export type AdminPageTemplate = {
  id: string;
  label: string;
  description: string;
  blocks: (title: string) => { id: string; type: string; props: Record<string, unknown> }[];
};

const EYEBROW: AdminField = { name: "eyebrow", label: "Eyebrow", type: "text", help: "Small label above the heading." };

/** Field descriptors per block type (merge into BLOCK_FIELDS). */
export const hantverkBlockFields: Record<string, AdminField[]> = {
  emergencyBanner: [
    { name: "text", label: "Text", type: "text", placeholder: "Jour dygnet runt vid vattenskada" },
    { name: "phone", label: "Phone", type: "text", help: "Leave empty to use the site phone number." },
    { name: "note", label: "Note", type: "text", help: "Short extra line, e.g. F-skatt · Org.nr. Hidden on phones." },
    {
      name: "mobileBar",
      label: "Mobile call/quote bar",
      type: "object",
      fields: [
        { name: "enabled", label: "Show on phones", type: "boolean" },
        { name: "callLabel", label: "Call label", type: "text", placeholder: "Ring" },
        { name: "quoteLabel", label: "Quote label", type: "text", placeholder: "Begär offert" },
        { name: "quoteHref", label: "Quote link", type: "text", placeholder: "#offert" },
      ],
    },
  ],
  trustBar: [
    {
      name: "items",
      label: "Promises & credentials",
      type: "array",
      itemLabel: "{title}",
      fields: [
        { name: "title", label: "Title", type: "text" },
        { name: "text", label: "Text", type: "text" },
      ],
    },
  ],
  rotCalculator: [
    EYEBROW,
    { name: "heading", label: "Heading", type: "text" },
    { name: "intro", label: "Intro", type: "textarea" },
    { name: "rate", label: "ROT rate (%)", type: "number", min: 0, max: 100, help: "30 % in 2026. Check Skatteverket when the rules change." },
    { name: "capPerPerson", label: "Max deduction per person (kr)", type: "number", min: 0 },
    { name: "maxAmount", label: "Slider max (kr)", type: "number", min: 10000 },
    { name: "defaultLabor", label: "Default labour cost (kr)", type: "number", min: 0 },
    { name: "defaultMaterial", label: "Default material (kr)", type: "number", min: 0 },
    { name: "defaultPersons", label: "Default persons", type: "select", options: [1, 2] },
    { name: "note", label: "Fine print", type: "text", help: "Replaces the automatic rate/cap line." },
    { name: "cta", label: "Button", type: "link" },
  ],
  beforeAfter: [
    EYEBROW,
    { name: "heading", label: "Heading", type: "text" },
    { name: "intro", label: "Intro", type: "textarea" },
    { name: "before", label: "Before image", type: "image" },
    { name: "after", label: "After image", type: "image" },
    { name: "beforeLabel", label: "Before label", type: "text", placeholder: "Före" },
    { name: "afterLabel", label: "After label", type: "text", placeholder: "Efter" },
    {
      name: "facts",
      label: "Facts",
      type: "array",
      itemLabel: "{label}",
      fields: [
        { name: "label", label: "Label", type: "text" },
        { name: "value", label: "Value", type: "text" },
      ],
    },
    { name: "cta", label: "Link", type: "link" },
  ],
  quoteRequest: [
    EYEBROW,
    { name: "heading", label: "Heading", type: "text" },
    { name: "intro", label: "Intro", type: "textarea" },
    { name: "formId", label: "Form ID", type: "text", help: "Identifies the form in the Inbox." },
    { name: "areasLabel", label: "Areas label", type: "text", placeholder: "Vi arbetar i" },
    { name: "areas", label: "Service areas", type: "array", itemLabel: "{value}", fields: [{ name: "value", label: "Area", type: "text" }] },
    { name: "jobTypes", label: "Job types", type: "array", itemLabel: "{value}", fields: [{ name: "value", label: "Job type", type: "text" }] },
    { name: "timings", label: "Start options", type: "array", itemLabel: "{value}", fields: [{ name: "value", label: "Option", type: "text" }] },
    { name: "submitLabel", label: "Submit label", type: "text" },
    { name: "successMessage", label: "Success message", type: "text" },
    { name: "consent", label: "Consent / privacy text", type: "textarea" },
  ],
};

/** Extra hero field, only rendered by the Hantverk hero (append to BLOCK_FIELDS.hero). */
export const hantverkHeroFields: AdminField[] = [
  {
    name: "quickQuote",
    label: "Quick quote card (S-Hub Hantverk)",
    type: "object",
    help: "Only the Hantverk hero shows it. Chips link to the quote form with the job preselected.",
    fields: [
      { name: "label", label: "Label", type: "text", placeholder: "Snabboffert" },
      { name: "title", label: "Title", type: "text", placeholder: "Vad behöver du hjälp med?" },
      { name: "options", label: "Job chips", type: "array", itemLabel: "{value}", fields: [{ name: "value", label: "Job", type: "text" }] },
      { name: "href", label: "Quote link", type: "text", placeholder: "#offert" },
      { name: "linkLabel", label: "Link label", type: "text", placeholder: "Fortsätt till offert" },
    ],
  },
];

/** Required top-level fields per block type (merge into REQUIRED_FIELDS). */
export const hantverkRequiredFields: Record<string, string[]> = {
  emergencyBanner: [],
  trustBar: [],
  rotCalculator: ["heading"],
  beforeAfter: ["heading", "before", "after"],
  quoteRequest: ["heading", "formId"],
};

/** Block-picker templates (THEME_BLOCKS.hantverk). */
export const hantverkBlockTemplates: AdminBlockTemplate[] = [
    {
      type: "emergencyBanner",
      label: "Jour banner",
      description: "Emergency/jour strip under the header plus a sticky call/quote bar on phones.",
      icon: "phone",
      template: {
        text: "Jour dygnet runt vid vattenskada",
        mobileBar: { enabled: true, callLabel: "Ring", quoteLabel: "Begär offert", quoteHref: "#offert" },
      },
    },
    {
      type: "trustBar",
      label: "Trust bar",
      description: "Credentials and promises: F-skatt, behörighet, fast pris, garanti.",
      icon: "shield",
      template: {
        items: [
          { title: "Fast pris", text: "Det offererade priset gäller" },
          { title: "ROT direkt", text: "Avdraget dras på fakturan" },
          { title: "Behörighet", text: "Certifierade för våtrum" },
          { title: "Garanti", text: "På utfört arbete" },
        ],
      },
    },
    {
      type: "rotCalculator",
      label: "ROT calculator",
      description: "Interactive price estimate after ROT-avdrag. Rate and cap are editable.",
      icon: "calculator",
      template: {
        eyebrow: "ROT-avdrag",
        heading: "Räkna på ditt pris efter avdrag",
        intro: "ROT gäller arbetskostnaden, inte material. Vi gör avdraget direkt på fakturan.",
        rate: 30,
        capPerPerson: 50000,
      },
    },
    {
      type: "beforeAfter",
      label: "Before / after",
      description: "One project with a before/after comparison slider and key facts.",
      icon: "image",
      template: {
        eyebrow: "Projekt",
        heading: "Badrum",
        before: { src: "/hantverk/fore.svg", alt: "Badrummet före renovering" },
        after: { src: "/hantverk/efter.svg", alt: "Badrummet efter renovering" },
        facts: [{ label: "Tid", value: "3 veckor" }],
      },
    },
    {
      type: "quoteRequest",
      label: "Quote request",
      description: "Three-step quote form (job, details, contact) that lands in S-Hub Inbox.",
      icon: "clipboard",
      template: {
        eyebrow: "Offert",
        heading: "Berätta om jobbet",
        intro: "Hembesök och offert är kostnadsfria.",
        formId: "hantverk-offert",
        areas: [],
      },
    },
];

const block = (id: string, type: string, props: Record<string, unknown>) => ({ id, type, props });

/** Page templates offered when creating a page with this theme active. */
export const hantverkPageTemplates: AdminPageTemplate[] = [
  {
    id: "hantverk-service",
    label: "Service page",
    description: "Hero, trust bar, process, ROT calculator and quote form.",
    blocks: (title) => [
      block("hero", "hero", { heading: title, intro: "Beskriv tjänsten kort och tydligt." }),
      block("trust", "trustBar", { items: [] }),
      block("process", "process", { heading: "Så går det till", steps: [] }),
      block("rot", "rotCalculator", { heading: "Räkna på ditt pris efter avdrag", rate: 30, capPerPerson: 50000 }),
      block("offert", "quoteRequest", { heading: "Begär offert", formId: "hantverk-offert" }),
    ],
  },
  {
    id: "hantverk-project",
    label: "Project page",
    description: "Hero, before/after and quote form.",
    blocks: (title) => [
      block("hero", "hero", { heading: title, intro: "Om projektet." }),
      block("project", "beforeAfter", {
        heading: title,
        before: { src: "/hantverk/fore.svg", alt: "Före" },
        after: { src: "/hantverk/efter.svg", alt: "Efter" },
        facts: [],
      }),
      block("offert", "quoteRequest", { heading: "Vill du ha något liknande?", formId: "hantverk-offert" }),
    ],
  },
];
