import { z } from "zod";
import type { SectionComponent } from "@staark/theme-kit";
import { Container } from "@staark/theme-light";
import { optionalLink, SectionHead } from "../components/shared";
import { RotWidget } from "../components/RotWidget";
import { formatKr } from "../rot";

const schema = z.object({
  eyebrow: z.string().optional(),
  heading: z.string(),
  intro: z.string().optional(),
  /** Deduction rate in percent. 30 in 2026 — keep it editable, the rules change. */
  rate: z.coerce.number().min(0).max(100).default(30),
  /** Max deduction per person and year, in kronor. */
  capPerPerson: z.coerce.number().min(0).default(50000),
  maxAmount: z.coerce.number().min(10000).default(400000),
  step: z.coerce.number().min(100).default(5000),
  defaultLabor: z.coerce.number().min(0).default(120000),
  defaultMaterial: z.coerce.number().min(0).default(80000),
  defaultPersons: z.coerce.number().int().min(1).max(2).default(2),
  note: z.string().optional(),
  cta: optionalLink,
});

/**
 * ROT calculator — lets a visitor estimate the price after ROT-avdrag. The
 * section is server-rendered; only the widget hydrates. Block type: "rotCalculator".
 */
export const RotCalculator: SectionComponent<z.infer<typeof schema>> = ({ props }) => {
  const p = schema.parse(props);
  const rule = `Sats ${p.rate} % · max ${formatKr(p.capPerPerson)} per person och år. Uppskattning, inte offert.`;

  return (
    <section className="sk-section sk-hv-rot" id="rot">
      <Container>
        <div className="sk-hv-rot__grid">
          <div className="sk-hv-rot__copy">
            <SectionHead eyebrow={p.eyebrow} heading={p.heading} intro={p.intro} tone="dark" />
            <p className="sk-hv-rot__rule">{p.note ?? rule}</p>
            {p.cta ? (
              <a className="sk-btn sk-btn--primary sk-hv-btn" href={p.cta.href}>
                {p.cta.label}
              </a>
            ) : null}
          </div>
          <RotWidget
            ratePercent={p.rate}
            capPerPerson={p.capPerPerson}
            maxAmount={p.maxAmount}
            step={p.step}
            defaultLabor={Math.min(p.defaultLabor, p.maxAmount)}
            defaultMaterial={Math.min(p.defaultMaterial, p.maxAmount)}
            defaultPersons={p.defaultPersons === 1 ? 1 : 2}
            labels={{
              labor: "Arbetskostnad",
              material: "Material",
              persons: "Antal som delar avdraget",
              total: "Totalt före avdrag",
              deduction: "ROT-avdrag",
              pay: "Du betalar",
              capped: "Avdraget är begränsat av maxbeloppet.",
            }}
          />
        </div>
      </Container>
    </section>
  );
};
