import { z } from "zod";
import type { SectionComponent } from "@staark/theme-kit";
import { Container } from "@staark/theme-light";
import { CheckIcon } from "../components/shared";

const schema = z.object({
  items: z.array(z.object({ title: z.string(), text: z.string().optional() })).default([]),
});

/**
 * Trust bar — the promises and credentials a trades customer checks first
 * (F-skatt, behörighet, fast pris, garanti). Block type: "trustBar".
 */
export const TrustBar: SectionComponent<z.infer<typeof schema>> = ({ props }) => {
  const p = schema.parse(props);
  if (!p.items.length) return null;
  return (
    <section className="sk-hv-trust" aria-label="Därför väljer kunder oss">
      <Container>
        <ul className="sk-hv-trust__list">
          {p.items.map((item) => (
            <li key={item.title} className="sk-hv-trust__item">
              <span className="sk-hv-trust__icon">
                <CheckIcon />
              </span>
              <span className="sk-hv-trust__text">
                <strong>{item.title}</strong>
                {item.text ? <span>{item.text}</span> : null}
              </span>
            </li>
          ))}
        </ul>
      </Container>
    </section>
  );
};
