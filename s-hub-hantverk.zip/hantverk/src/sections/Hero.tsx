import { z } from "zod";
import type { SectionComponent } from "@staark/theme-kit";
import { Container, siteCta } from "@staark/theme-light";
import { imageSchema, optionalLink, PhoneIcon, telHref } from "../components/shared";

const schema = z.object({
  eyebrow: z.string().optional(),
  heading: z.string(),
  intro: z.string().optional(),
  primaryCta: optionalLink,
  secondaryCta: optionalLink,
  /** Show a "call us" button with the site phone when no secondary CTA is set. */
  showPhone: z.boolean().default(true),
  image: imageSchema.optional(),
  points: z.array(z.string()).default([]),
  quickQuote: z
    .object({
      title: z.string().default("Vad behöver du hjälp med?"),
      label: z.string().default("Snabboffert"),
      href: z.string().default("#offert"),
      linkLabel: z.string().default("Fortsätt till offert"),
      options: z.array(z.string()).default([]),
    })
    .optional(),
});

function withJob(href: string, job: string): string {
  const [path, hash] = href.split("#");
  const sep = path!.includes("?") ? "&" : "?";
  return `${path}${sep}jobb=${encodeURIComponent(job)}${hash !== undefined ? `#${hash}` : ""}`;
}

/**
 * Hantverk hero — overrides the S-Hub Light hero (same props, plus an optional
 * "snabboffert" card). The chips are plain links that preselect the job type in
 * the quoteRequest block through ?jobb=, so the hero stays a server component.
 */
export const Hero: SectionComponent<z.infer<typeof schema>> = ({ props, ctx }) => {
  const p = schema.parse(props);
  const primary = p.primaryCta ?? siteCta(ctx.site);
  const phone = ctx.site.contact.phone;
  const HostImage = ctx.image;
  const priority = (ctx.blockIndex ?? Infinity) <= 1;

  return (
    <section className="sk-hv-hero">
      <Container wide>
        <div className="sk-hv-hero__grid">
          <div className="sk-hv-hero__body">
            {p.eyebrow ? <p className="sk-eyebrow">{p.eyebrow}</p> : null}
            <h1 className="sk-hv-hero__title">{p.heading}</h1>
            {p.intro ? <p className="sk-hv-hero__intro">{p.intro}</p> : null}
            <div className="sk-hv-hero__actions">
              <a className="sk-btn sk-btn--primary sk-hv-btn" href={primary.href}>
                {primary.label}
              </a>
              {p.secondaryCta ? (
                <a className="sk-hv-btn sk-hv-btn--outline" href={p.secondaryCta.href}>
                  {p.secondaryCta.href.startsWith("tel:") ? <PhoneIcon /> : null}
                  {p.secondaryCta.label}
                </a>
              ) : p.showPhone && phone ? (
                <a className="sk-hv-btn sk-hv-btn--outline" href={telHref(phone)}>
                  <PhoneIcon />
                  Ring {phone}
                </a>
              ) : null}
            </div>
            {p.points.length ? (
              <ul className="sk-hv-hero__points">
                {p.points.map((point) => (
                  <li key={point}>{point}</li>
                ))}
              </ul>
            ) : null}
          </div>

          <div className="sk-hv-hero__media">
            <div className="sk-hv-hero__frame">
              {p.image ? (
                HostImage ? (
                  <HostImage src={p.image.src} alt={p.image.alt} fill sizes="(max-width: 900px) 100vw, 46vw" priority={priority} eager={priority} className="sk-hv-cover" />
                ) : (
                  <img src={p.image.src} alt={p.image.alt} className="sk-hv-cover" />
                )
              ) : null}
            </div>
            {p.quickQuote && p.quickQuote.options.length ? (
              <aside className="sk-hv-quick" aria-label={p.quickQuote.label}>
                <p className="sk-hv-quick__label">{p.quickQuote.label}</p>
                <p className="sk-hv-quick__title">{p.quickQuote.title}</p>
                <ul className="sk-hv-quick__chips">
                  {p.quickQuote.options.map((option) => (
                    <li key={option}>
                      <a className="sk-hv-chip" href={withJob(p.quickQuote!.href, option)}>
                        {option}
                      </a>
                    </li>
                  ))}
                </ul>
                <a className="sk-hv-quick__link" href={p.quickQuote.href}>
                  {p.quickQuote.linkLabel} →
                </a>
              </aside>
            ) : null}
          </div>
        </div>
      </Container>
    </section>
  );
};
