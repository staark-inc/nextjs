import { z } from "zod";
import type { SectionComponent } from "@staark/theme-kit";
import { Container } from "@staark/theme-light";
import { imageSchema, optionalLink, SectionHead } from "../components/shared";
import { CompareSlider } from "../components/CompareSlider";

const schema = z.object({
  eyebrow: z.string().optional(),
  heading: z.string(),
  intro: z.string().optional(),
  before: imageSchema,
  after: imageSchema,
  beforeLabel: z.string().default("Före"),
  afterLabel: z.string().default("Efter"),
  facts: z.array(z.object({ label: z.string(), value: z.string() })).default([]),
  cta: optionalLink,
});

/**
 * Before/after — one project shown with a comparison slider and a few key
 * facts (tid, behörighet, yta). Block type: "beforeAfter".
 */
export const BeforeAfter: SectionComponent<z.infer<typeof schema>> = ({ props }) => {
  const p = schema.parse(props);
  return (
    <section className="sk-section sk-hv-project" id="projekt">
      <Container>
        <div className="sk-hv-project__grid">
          <div className="sk-hv-project__copy">
            <SectionHead eyebrow={p.eyebrow} heading={p.heading} intro={p.intro} />
            {p.facts.length ? (
              <dl className="sk-hv-facts">
                {p.facts.map((fact) => (
                  <div key={fact.label}>
                    <dt>{fact.label}</dt>
                    <dd>{fact.value}</dd>
                  </div>
                ))}
              </dl>
            ) : null}
            {p.cta ? (
              <a className="sk-hv-textlink" href={p.cta.href}>
                {p.cta.label} →
              </a>
            ) : null}
          </div>
          <CompareSlider before={p.before} after={p.after} beforeLabel={p.beforeLabel} afterLabel={p.afterLabel} hint="Dra för att jämföra före och efter" />
        </div>
      </Container>
    </section>
  );
};
