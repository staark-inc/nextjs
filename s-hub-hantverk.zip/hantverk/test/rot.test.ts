import { test } from "node:test";
import assert from "node:assert/strict";
import { computeRot, formatKr } from "../src/rot.ts";

const base = { material: 80_000, persons: 2, ratePercent: 30, capPerPerson: 50_000 };

test("deducts the rate from labour only", () => {
  const r = computeRot({ ...base, labor: 120_000 });
  assert.equal(r.total, 200_000);
  assert.equal(r.deduction, 36_000);
  assert.equal(r.pay, 164_000);
  assert.equal(r.capped, false);
});

test("caps the deduction per person", () => {
  const one = computeRot({ ...base, labor: 400_000, persons: 1 });
  assert.equal(one.deduction, 50_000);
  assert.equal(one.capped, true);
  const two = computeRot({ ...base, labor: 400_000, persons: 2 });
  assert.equal(two.deduction, 100_000);
});

test("ignores invalid input", () => {
  const r = computeRot({ labor: -5, material: Number.NaN, persons: 0, ratePercent: 30, capPerPerson: 50_000 });
  assert.deepEqual(r, { total: 0, deduction: 0, pay: 0, capped: false });
});

test("formats kronor the Swedish way", () => {
  assert.equal(formatKr(164000).replace(/\s/g, " "), "164 000 kr");
});
